# RPCClientServerCalc
Client Server Calculator using Remote Procedure Call migrated from Remote Method Invocation.
