class multCalc:
    def mul(self, arg1, arg2): 
        return arg1*arg2

class addCalc:
    def add(self, arg1, arg2): 
        return arg1+arg2

class subCalc:
    def sub(self, arg1, arg2): 
        return arg1-arg2
    
class divCalc:
    def div(self, arg1, arg2): 
        return arg1/arg2