package com.company.calculatorws.calculator.handler;

public interface MessageHandler {

	String process(String message);
	
}
